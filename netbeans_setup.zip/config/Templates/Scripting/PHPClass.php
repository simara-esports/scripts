<?php

namespace ;

/**
 * Description of ${name}
 *
 * @author ${user}
 */
class ${name} extends \Nette\Object{

}
